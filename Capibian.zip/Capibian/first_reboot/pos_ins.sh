#!/bin/bash

# seta novo nome
#numero_al=`tr -dc 0-9 < /dev/urandom  | head -c 5`
#novo_nome="capibian-"$numero_al
serial=`dmidecode -s system-serial-number`
novo_nome="capibian-"${serial: -5}
hostnamectl set-hostname $novo_nome

# atualizar chaves ssh
#rm /etc/ssh/moduli
rm /etc/ssh/ssh_host*
#ssh-keygen -M generate -O bits=4096 /etc/ssh/moduli
ssh-keygen -A -N ""

# colocar teclado em português
setxkbmap -model abnt2 -layout br

# remover inicialização automática desse script
rm /etc/cron.d/pos_ins
#rm /root/pos_ins.sh
