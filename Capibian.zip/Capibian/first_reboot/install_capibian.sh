#!/bin/bash

# seta novo nome
#serial=`dmidecode -s system-serial-number`
#echo "número de série : $serial"
#new_nome="capibian-"${serial: -5}
#echo "novo nome       : $new_nome"

# executar script para reconhecer wifi no boot

# atualizar chaves ssh

# colocar teclado em português

# instalar pacotes

# alterar slim.conf

# remover ícones desnecessários

# adicionar wallpaper

# adicionar ícones dos novos aplicativos

# remover inicialização automática desse script
